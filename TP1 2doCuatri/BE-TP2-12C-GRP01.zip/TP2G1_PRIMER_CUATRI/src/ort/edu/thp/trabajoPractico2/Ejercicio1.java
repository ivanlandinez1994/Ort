package ort.edu.thp.trabajoPractico2;

public class Ejercicio1 {
	public static void main(String args[]){
		int numero = 0;
		while(numero<100){
			numero++;
			System.out.println(numero);
		}
	}
}
//1. Realizar un programa que muestre los n�meros del 1 al 100 utilizando la instrucci�n while 

