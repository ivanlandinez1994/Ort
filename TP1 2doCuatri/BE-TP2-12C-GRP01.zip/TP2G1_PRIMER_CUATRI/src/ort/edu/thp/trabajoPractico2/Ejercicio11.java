package ort.edu.thp.trabajoPractico2;
import java.util.Scanner;
public class Ejercicio11 {
	private static Scanner sc = new Scanner(System.in);	
	private static double COSTO_ADICIONAL_VIAJE=100, DESCUENTO = 10, PRECIO_BASE=8500;
	private static int MIN_VIAJE_ADICIONAL=0, MAX_VIAJE_ADICIONAL=1000;
	public static void main(String[] args) {
		int contador=0, cantidadViajesAdicionales,cantidadEmpresas;		
		double promedioPagadoPorEmpresa,totalPagadoEmpresas=0, totalFactura, valorFacturaMasCara=0;
		String nombreEmpresaFacturaMascara="",nombreEmpresa;	
		
		cantidadEmpresas = validarEnteroConMinimo("Ingrese la cantidad de empresas a ingresar",0);
		while(contador<cantidadEmpresas){			
			System.out.println("Ingrese nombre de la empresa");				
			nombreEmpresa = sc.nextLine();
			
			cantidadViajesAdicionales = validarEnteroMinimoMaximo("Ingrese la cantidad de viajes adicionales que debe"
					+ " ser mayor a "+MIN_VIAJE_ADICIONAL+" y menor a "+MAX_VIAJE_ADICIONAL,
					MIN_VIAJE_ADICIONAL, MAX_VIAJE_ADICIONAL);
			
			if(cantidadViajesAdicionales>30) {
				totalFactura = (PRECIO_BASE+(cantidadViajesAdicionales*COSTO_ADICIONAL_VIAJE))*((100-DESCUENTO)/100);
			}else {
				totalFactura = PRECIO_BASE+(cantidadViajesAdicionales*COSTO_ADICIONAL_VIAJE);
			}
			
			System.out.println("La empresa "+nombreEmpresa+" que necesito hacer "+cantidadViajesAdicionales+""
					+ " viajes adicionales en el mes,\ndebera pagar una factura de $"+totalFactura+"\n");
			totalPagadoEmpresas=totalPagadoEmpresas+totalFactura;
			if(totalFactura>valorFacturaMasCara) {
				nombreEmpresaFacturaMascara = nombreEmpresa;
				valorFacturaMasCara = totalFactura;
			}
			contador++;
		}
		promedioPagadoPorEmpresa = totalPagadoEmpresas/cantidadEmpresas;
		System.out.println("El promedio pagado por empresa en el pasado mes fue de $"
					+promedioPagadoPorEmpresa+"\n"+ 
					"La empresa "+nombreEmpresaFacturaMascara+" tuvo la factura mas alta con un total de $"+valorFacturaMasCara);
	}
	
	public static int validarEnteroMinimoMaximo(String mensaje, int min, int max) {
		int numero;
		System.out.println(mensaje);
		numero = sc.nextInt();
		while(numero<min || numero>max) {
			System.out.println("Error, "+mensaje);
			numero = sc.nextInt();
		}
		return numero;
	}
	public static int validarEnteroConMinimo(String mensaje, int min) {
		int num;
		System.out.println(mensaje);
		num = sc.nextInt();
		while (num < min) {
			System.out.println("Error, valor ingresado no valido. \n" + mensaje);
			num = sc.nextInt();
		}
		return num;
	}
}


//11. Una empresa dedicada al transporte de documentaci�n necesita procesar su facturaci�n
//mensual a partir de los res�menes de viajes realizados para cada uno de sus clientes.
//Quieren saber tambi�n cu�l es el promedio pagado por empresa y el valor de la factura m�s
//cara. Para el c�lculo de cada factura se sabe que por mes cada empresa tiene derecho a dos
//viajes diarios libres con un abono de $8500, cobrando adem�s por cada viaje adicional $100.
//En caso de que la empresa supere los 30 viajes adicionales, por promoci�n, se le har� un
//descuento del 10% sobre el total mensual facturado. Por cada empresa nos informan el
//nombre de la misma y la cantidad de viajes adicionales (entero >=0, siempre menor a 1000),
//y nosotros debemos mostrar en pantalla su nombre y el importe total de la factura. 

