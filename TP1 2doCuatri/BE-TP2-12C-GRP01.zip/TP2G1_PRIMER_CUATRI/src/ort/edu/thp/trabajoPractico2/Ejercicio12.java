package ort.edu.thp.trabajoPractico2;
import java.util.Scanner;
public class Ejercicio12 {
	private static Scanner sc = new Scanner(System.in);
	private static int MIN_COD_CLIENTE=10001, MAX_COD_CLIENTE=99999, VALOR_CORTE = 0;		
	private static double COSTO_A=2,COSTO_B=2,COSTO_B_EXTRA=1.5,COSTO_C=1,COSTO_C_FIJO=10;
	private static double MIN_HASTA_COSTO_EXTRA_B=5;
	public static void main(String[] args) {
		int codigoCliente=1, contador=0, duracionLlamada, duracionLLamadaMasLarga=0;
		char tipoAbono;				
		double importeTotalTipoA=0,importeTotalTipoB=0,importeTotalTipoC=0;		
		int cantidadLlamadasMenos6Minutos=0;
		double precioPromedioLlamada;
		codigoCliente = validarEnteroMinMaxyExcepcion("Ingrese codigo de cliente de 5 digitos entre " 
				+MIN_COD_CLIENTE+" y "+MAX_COD_CLIENTE+", si desea salir presione "+VALOR_CORTE,
				MIN_COD_CLIENTE,MAX_COD_CLIENTE,VALOR_CORTE);
		while(codigoCliente!=0){	
			contador++;
			duracionLlamada = validarEnteroConMinimo("Ingrese duracion de la llamada en minutos", VALOR_CORTE+1);
			tipoAbono = validarTipoAbono("Ingrese el tipo de abono 'A,B,C'");
			switch(tipoAbono) {
			case 'A': case 'a':
				importeTotalTipoA = importeTotalTipoA + (duracionLlamada*COSTO_A);
				break;
			case 'B': case 'b':
				if(duracionLlamada<=MIN_HASTA_COSTO_EXTRA_B) {
					importeTotalTipoB = importeTotalTipoA + (duracionLlamada*COSTO_B);
				}else {
					importeTotalTipoB = importeTotalTipoB + ((MIN_HASTA_COSTO_EXTRA_B*COSTO_B)+((duracionLlamada-MIN_HASTA_COSTO_EXTRA_B)*COSTO_B_EXTRA));
				}				  				
				break;
			case 'C': case 'c':
				if((duracionLlamada*COSTO_C)<COSTO_C_FIJO) {
					importeTotalTipoC = importeTotalTipoC + (duracionLlamada*COSTO_C);
				}else {
					importeTotalTipoC = importeTotalTipoC +COSTO_C_FIJO;
				}
				break;
			}
			if(duracionLlamada>duracionLLamadaMasLarga){
				duracionLLamadaMasLarga = duracionLlamada;
			}
			if(duracionLlamada<6) {
				cantidadLlamadasMenos6Minutos++;
			}
			codigoCliente = validarEnteroMinMaxyExcepcion("Ingrese codigo de cliente de 5 digitos entre " 
					+MIN_COD_CLIENTE+" y "+MAX_COD_CLIENTE+", si desea salir presione "+VALOR_CORTE,
					MIN_COD_CLIENTE,MAX_COD_CLIENTE,VALOR_CORTE);
		}
		if(contador==0) {
			System.out.println("No se obtuvo ningun resultado");
			System.out.println("Programa finalizado!");
		}else {
			precioPromedioLlamada = (importeTotalTipoA +importeTotalTipoB + importeTotalTipoC)/contador;
			System.out.println("El importe acumulado por el tipo de abono A es: "+importeTotalTipoA+"\n"
					+"El importe acumulador por el tiempo de abono B es: "+importeTotalTipoB+"\n"
					+"El importe acumulador por el tiempo de abono C es: "+importeTotalTipoC+"\n\n"
					+"La cantidad de minutos de la llamada mas larga es: "+duracionLLamadaMasLarga+"\n"
					+"La cantidad de llamadas de menos de 6 minutos fue: "+cantidadLlamadasMenos6Minutos+"\n"
					+"El precio promedio por llamada es: "+precioPromedioLlamada+"\n");
		}		
	}
	public static int validarEnteroMinMaxyExcepcion(String mensaje, int min, int max, int excepcion) {
		int num;
		System.out.println(mensaje);
		num = sc.nextInt();
		while ((num < min || num > max) && num!=0) {
			System.out.println("Error, valor ingresado no valido. \n" + mensaje);
			num = sc.nextInt();
		}
		return num;
	}
	public static int validarEnteroConMinimo(String mensaje, int min) {
		int num;
		System.out.println(mensaje);
		num = sc.nextInt();
		while (num < min) {
			System.out.println("Error, valor ingresado no valido. \n" + mensaje);
			num = sc.nextInt();
		}
		return num;
	}
	public static char validarTipoAbono(String mensaje) {
		char tipoAbono;
		System.out.println(mensaje);
		tipoAbono = sc.next().charAt(0);
		while(tipoAbono!= 'A' && tipoAbono !='B' && tipoAbono !='C' && tipoAbono!='a' && tipoAbono!='b' && tipoAbono!='c') {
			System.out.println("Error, "+mensaje);
			tipoAbono = sc.next().charAt(0);
		}
		return tipoAbono;
	}
}
/*12. Una empresa de telefon�a nos pide escribir un programa que le brinde informaci�n sobre
el consumo de sus clientes residenciales. 
Para ello se ingresa, por cada una de las llamadas
realizadas en el �ltimo mes:
- C�digo de Cliente (int de 5 d�gitos, entre 10001 y 99999, 0 = fin)
- Duraci�n de la llamada nro. (int > 0).
- Tipo de abono (�A�, �B� o �C�).
 
Para calcular el importe de cada llamada, nos informan que el costo por minuto, de acuerdo
al tipo de abono, es el siguiente: 
- Abono �A� => $2 el minuto
- Abono �B� => Hasta 5 minutos, $2 el minuto; M�s de 5 minutos, $1,5 el minuto.
- Abono �C� => $1 el minuto con un m�ximo de $10 (Ej. si habla 15 minutos paga $10).
Se pide informar:
1. El importe acumulado a recaudar por cada tipo de abono.
2. La cantidad de minutos de la llamada m�s larga.
3. La cantidad de llamadas de menos de 6 minutos.
4. El precio promedio por llamada. */