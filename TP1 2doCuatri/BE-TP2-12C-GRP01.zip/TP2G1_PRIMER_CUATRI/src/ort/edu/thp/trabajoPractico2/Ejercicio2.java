package ort.edu.thp.trabajoPractico2;

public class Ejercicio2 {
	public static void main(String args[]) {
		int numero = 0;
		do {
			numero++;
			System.out.println(numero);
		}while(numero<100);
	}
}
//2. Realizar un programa que muestre los n�meros del 1 al 100 utilizando la instrucci�n do while 
