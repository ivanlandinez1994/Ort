package ort.edu.thp.trabajoPractico2;

public class Ejercicio3 {
	public static void main(String args[])
	{
		for(int i=1;i<=100;i++) {
			System.out.println(i);
		}
	}
}
//3. Realizar un programa que muestre los n�meros del 1 al 100 utilizando la instrucci�n for 
