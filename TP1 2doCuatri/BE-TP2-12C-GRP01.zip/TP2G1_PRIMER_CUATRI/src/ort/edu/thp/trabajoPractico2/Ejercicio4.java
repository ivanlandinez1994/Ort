package ort.edu.thp.trabajoPractico2;

import java.util.Scanner;

public class Ejercicio4 {
	private static Scanner sc = new Scanner(System.in);

	public static void main(String args[]) {
		int cantVentas = 0;
		double importeVentas;
		double sumatoriaVentas = 0;
		cantVentas = validarEnteroConMinimo("Ingresa el numero de ventas a introducir o presione 0 para salir", 0);

		for (int i = 0; i < cantVentas; i++) {
			importeVentas = validarEnteroConMinimo("Ingrese el importe de la venta " + (i + 1) + "\n", 1);

			System.out.println("El importe ingresado fue " + importeVentas);
			sumatoriaVentas = sumatoriaVentas + importeVentas;
		}
		if (cantVentas == 0) {
			System.out.println("No existen valores ingresados");
		} else {
			System.out.println("La sumatoria de todas las ventas fue " + sumatoriaVentas);
		}

		sc.close();
	}

	public static int validarEnteroConMinimo(String mensaje, int min) {
		int num;
		System.out.println(mensaje);
		num = sc.nextInt();
		while (num < min) {
			System.out.println("Error, valor ingresado no valido. \n" + mensaje);
			num = sc.nextInt();
		}
		return num;
	}
}
//4. Realizar un programa que le pida al usuario un n�mero de ventas a introducir. Luego, pedir
//el importe de las mismas tantas veces como n�mero de ventas se hayan indicado. Al final
//mostrar por pantalla la suma de todas las ventas.

