package ort.edu.thp.trabajoPractico2;

import java.util.Scanner;

public class Ejercicio5 {
	/*
	 * Se tiene en cuenta que puede haber mas de un ganador pero dado que no hemos
	 * visto una manera de almacenar mas de un valor se tomo solo el primer valor
	 */
	private static Scanner sc = new Scanner(System.in);
	private static int VALOR_SALIDA = 0;

	public static void main(String args[]) {
		int numeroCorredor = -1, horas, minutos, segundos;		
		int numeroCorredorMenosTiempo = 0, totalSegundosCorredorMenosTiempo = 999999999, totalSegundosCorredores = 0;
		int contadorCorredores = 0, contadorCorredoresMenosUnaHora = 0;
		double promedioEnSegundosCorredores, porcentajeDeCorredoresMenosDeUnaHora;
		numeroCorredor = validarEnteroConMinimo("Ingrese numero de corredor o presione " + VALOR_SALIDA + " para salir",
				VALOR_SALIDA);

		while (numeroCorredor != 0) {
			horas = validarEnteroConMinimo("Ingrese horas que tardo en terminar la carrera", 0);
			minutos = validarEnteroConMinimo("Ingrese minutos que tardo en terminar la carrera", 0);
			segundos = validarEnteroConMinimo("Ingrese segundos que tardo en terminar la carrera", 0);

			if (devolverSegundos(horas, minutos, segundos) < totalSegundosCorredorMenosTiempo) {				
				numeroCorredorMenosTiempo = numeroCorredor;
				totalSegundosCorredorMenosTiempo = devolverSegundos(horas, minutos, segundos);
			}
			totalSegundosCorredores = totalSegundosCorredores + devolverSegundos(horas, minutos, segundos);
			contadorCorredores++;
			if (devolverSegundos(horas, minutos, segundos) < 3600) {
				contadorCorredoresMenosUnaHora++;
			}
			numeroCorredor = validarEnteroConMinimo(
					"Ingrese numero de corredor o presione " + VALOR_SALIDA + " para salir", VALOR_SALIDA);
		}
		if (contadorCorredores != 0) {
			promedioEnSegundosCorredores = totalSegundosCorredores / (double) contadorCorredores;
			porcentajeDeCorredoresMenosDeUnaHora = (contadorCorredoresMenosUnaHora / (double) contadorCorredores) * 100;

			System.out.println("El ganador fue el corredor: " + numeroCorredorMenosTiempo + " con un tiempo de: "
					+ totalSegundosCorredorMenosTiempo + " Segundos" + "\n"
					+ "El promedio en segundos de los corredores fue: " + promedioEnSegundosCorredores + " Segundos"
					+ "\n" + "El porcentaje de corredores que realizaron la carrera en menos de una hora fue: "
					+ porcentajeDeCorredoresMenosDeUnaHora + "%");
		} else {
			System.out.println("No hay resultados que mostrar�");
		}
	}

////////// FUNCIONES ////////////////
	public static int devolverSegundos(int hours, int minutes, int seconds) {
		int totalSegundos;
		totalSegundos = ((hours * 60) * 60) + (minutes * 60) + seconds;
		return totalSegundos;
	}

	public static int validarEnteroConMinimo(String mensaje, int min) {
		int num;
		System.out.println(mensaje);
		num = sc.nextInt();
		while (num < min) {
			System.out.println("Error, valor ingresado no valido. \n" + mensaje);
			num = sc.nextInt();
		}
		return num;
	}
}
/*
 * 5. El club de corredores nos pide un programa para obtener estad�sticas de la
 * carrera de 10 km. El mismo consiste en ingresar, por teclado, el n�mero de
 * corredor, las horas, los minutos y los segundos que tardo en realizar la
 * carrera. Tener en cuenta que al ingrear 0 como el n�mero de corredor,
 * finaliza el programa y debe mostrar por pantalla: a) El ganador b) El
 * promedio en segundos de los corredores. c) El porcentaje de corredores que
 * realizaron la carrera en menos de una hora. Programar y utilizar la funci�n
 * devolverSegundos que recibe como par�metros horas, minutos y segundos
 */