package ort.edu.thp.trabajoPractico2;
import java.util.Scanner;
public class Ejercicio6 {
	private static Scanner sc = new Scanner(System.in);
	private static int NUMERO_MINIMO=0;
	public static void main(String[] args) {
		int A,B,resultado=0;
		A = validarEnteroConMinimo("Ingrese el primer numero, no olvide que debe ser positivo", NUMERO_MINIMO);
		B = validarEnteroConMinimo("Ingrese el segundo numero, no olvide que debe ser positivo",NUMERO_MINIMO);						
		for(int i=0;i<B;i++) {
			System.out.println(resultado+"+"+A+"="+(resultado+A));
			resultado=resultado+A;
		}
	}
	
	public static int validarEnteroConMinimo(String mensaje, int min) {
		int num;
		System.out.println(mensaje);
		num = sc.nextInt();
		while(num<=0) {
			System.out.println("Error, valor ingresado debe ser mayor o igual a "+min);
			num = sc.nextInt();
		}
		return num;
	}
}
//6. Realiz� un programa que al ingresar dos n�meros enteros positivos llamados A y B se
//calcule el producto de �stos a trav�s de sumas sucesivas. Por ejemplo, si los n�meros son 4
//y 2, hacer 4 + 4; si son 5 y 3, hacer 5 + 5 + 5.
// �Qu� pasa si la diferencia entre los dos n�meros es muy grande? �Influye cu�l se usa para
//sumar y cu�l para contar la cantidad de sumas hechas? 
