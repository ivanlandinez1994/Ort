package ort.edu.thp.trabajoPractico2;
import java.util.Scanner;
public class Ejercicio7 {
	private static Scanner sc = new Scanner(System.in);
	private static int PROMEDIO_MAXIMO = 20;
	public static void main(String[] args) {
		int numero, contador=0, sumatoriaNumeros=0;
		double promedioNumeros=0;
		while(promedioNumeros<PROMEDIO_MAXIMO) {
			contador++;
			System.out.println("Ingrese numero "+contador);
			numero = sc.nextInt();
			sumatoriaNumeros=sumatoriaNumeros+numero;
			promedioNumeros = sumatoriaNumeros/(double)contador;
			
			System.out.println("Cantidad de ingresos: "+contador);
			System.out.println("Sumatoria numeros actual: "+sumatoriaNumeros);
			System.out.println("Promedio actual: "+promedioNumeros+"\n");
		}
			System.out.println("El programa finalizo dado que el promedio es igual o mayor a 20");
	}
}
//7. Realiz� un programa que lea una serie de n�meros mientras el promedio entre todos sea
//menor a 20. Informar la cantidad de valores le�dos. 