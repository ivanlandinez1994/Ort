package ort.edu.thp.trabajoPractico2;
import java.util.Scanner;
public class Ejercicio8 {
	/*
	 Se tiene en cuenta que puede haber mas de un mejor alumno pero dado que no hemos
	 visto una manera de almacenar mas de un valor se tomo solo el primer valor
	 */
	private static Scanner sc = new Scanner(System.in);
	private static int CANTIDAD_ALUMNOS = 10;
	public static void main(String[] args) {
		String nombre, nombreMejorAlumno="";
		double promedio=0, mejorPromedio=0;	
		int contador=0;
		while(contador<CANTIDAD_ALUMNOS) {
			System.out.println("Ingrese nombre");
			nombre = sc.next();
			System.out.println("Ingrese promedio");
			promedio = sc.nextDouble();
			while(promedio>10 || promedio<0) {
				System.out.println("Promedio no valido, ingrese promedio nuevamente");
				promedio = sc.nextDouble();
			}
			if(promedio>mejorPromedio) {
				mejorPromedio=promedio;
				nombreMejorAlumno=nombre;					
			}
			contador++;
		}
		System.out.println("El mejor alumno fue: "+nombreMejorAlumno+" con un promedio de: "+mejorPromedio);
	}

}
//8. Realiz� un programa en el cual se pida el nombre y el promedio de 10 alumnos.
//Al finalizar, debe mostrar por pantalla el nombre y el promedio del mejor.