package ort.edu.thp.trabajoPractico2;
import java.util.Scanner;
public class Ejercicio9 {
	private static Scanner sc = new Scanner(System.in);
	private static String USUARIO_CORRECTO = "ivan",CONTRASENA_CORRECTA = "123";
	private static int CANTIDAD_INTENTOS=3;
	public static void main(String[] args) {
		String usuario="",contrasena="";
		int contadorSalida=1;
		System.out.println("Usuario: ");
		usuario = sc.next();
		System.out.println("Contrase�a: ");
		contrasena = sc.next();
		while(contadorSalida<CANTIDAD_INTENTOS && 
				(!usuario.equals(USUARIO_CORRECTO) ||
						!contrasena.equals(CONTRASENA_CORRECTA))) {
			contadorSalida++;
			System.out.println("Error, alguno de los datos no es correcto");
			System.out.println("Usuario: ");
			usuario = sc.next();
			System.out.println("Contrase�a: ");
			contrasena = sc.next();
		}
		if(usuario.equals(USUARIO_CORRECTO) && contrasena.equals(CONTRASENA_CORRECTA)) {
			System.out.println("Bienvenido!!!");
		}
		else {
			System.out.println("Se ha bloqueado su cuenta");
		}
	}
}
/*
9. El ingreso a un sitio web se valida por nombre de usuario y contrase�a. Realizar un
programa que impida que el usuario ingrese hasta poner los datos correctos. Si intenta m�s
de 3 veces err�neamente, se debe mostrar el mensaje �Se ha bloqueado su cuenta�, de lo
contrario, mostrar �Ha ingresado correctamente�. 
*/