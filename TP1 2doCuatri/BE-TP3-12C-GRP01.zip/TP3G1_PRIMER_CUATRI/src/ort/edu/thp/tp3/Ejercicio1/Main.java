package ort.edu.thp.tp3.Ejercicio1;

public class Main {

	public static void main(String[] args) {
		Persona p1 = new Persona();
		Persona p2 = new Persona();
		p1.setNombre("Diego");
		p1.setApellido("Diaz");
		p1.setDireccion("Roosevelt 3313");
		p2.setNombre("Pablo");
		p2.setApellido("Gomez");
		p2.setDireccion("Virrey del pino 2284");
		System.out.println(p1.toString());
		System.out.println(p2.toString());
		
		p1.setNombre("Jhon Doe");
		System.out.println("Gracias al setter de nombre ahora la persona 1 se llama: "+p1.getNombre());
	}

}
//1. Crear una clase llamada Persona. La misma estar� compuesta por:
//� Atributos privados:
//- String nombre
//- String apellido
//- String direcci�n
//� M�todos p�blicos: setters y getters para cada atributo, y el m�todo toString().
//Codificar la funci�n main(), creando dos objetos Persona p1, Persona p2 con valores en sus atributos.
//Deber� utilizar los m�todos setters e imprimir por pantalla los valores de los atributos de cada objeto
//y mostrarlos por pantalla utilizando toString().
//El m�todo toString debe ser igual al siguiente ejemplo:
//@Override
//public String toString() {
//return "[Nombre:" + nombre + ", Apellido:" + apellido + �, Direccion:� + direccion ]";
//}
//La salida ser�:
//persona1 [Nombre:Diego, Apellido:Diaz, Direccion: Roosevelt 3313]
//persona2 [Nombre:Pablo, Apellido:Gomez, Direccion: Virrey del pino 2284]