package ort.edu.thp.tp3.Ejercicio2;

public class TarjetaCredito {
	private String numero;
	private String titular;
	private double limite;
	private double disponible;
	
	public TarjetaCredito(String numero, String titular, double limite) {
		this.setNumero(numero);
		this.setTitular(titular);
		this.setLimite(limite);
		this.setDisponible(limite);		
	}
	
	public String getNumero() {
		return numero;
	}
	public void setNumero(String numero) {
		this.numero = numero;
	}
	public String getTitular() {
		return titular;
	}
	public void setTitular(String titular) {
		this.titular = titular;
	}
	public double getLimite() {
		return limite;
	}
	public void setLimite(double limite) {
		this.limite = limite;
	}
	public double getDisponible() {
		return disponible;
	}
	public void setDisponible(double disponible) {
		this.disponible = disponible;
	}
	
	private boolean puedoComprar(double monto) {
		boolean bull=false;
		if (monto<=this.getDisponible()) {
			bull = true;
		}
		return bull;
	}
	
	public boolean realizarCompra(double monto) {
		boolean bull=false;
		if (puedoComprar(monto)) {
			this.setDisponible(this.getDisponible()-monto);			
			bull = true;
		}
		return bull;
	}
	
	public void actualizarLimite(double nuevoLimite) {
		double gap;
		gap = this.getLimite()-this.getDisponible();
		if (this.getDisponible()<0) {
			this.setDisponible(0);			
		}
		this.setLimite(nuevoLimite);
		if (nuevoLimite<=gap){
			this.setDisponible(0);
		}else{
			this.setDisponible(this.getLimite() - gap);
		}
	}
	
	@Override
	public String toString() {
		return "Tarjeta Credito [numero: " + numero + ", titular: " + titular + ", limite: " + limite
				+ ", disponible: " + disponible + "]";
	}
	

}
