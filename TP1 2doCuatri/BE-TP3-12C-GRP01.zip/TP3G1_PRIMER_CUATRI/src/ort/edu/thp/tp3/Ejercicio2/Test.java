package ort.edu.thp.tp3.Ejercicio2;

public class Test {

	public static void main(String[] args) {
		TarjetaCredito tarjeta = new TarjetaCredito("4145414122221111","Juan Perez",10000);
		System.out.println(tarjeta.realizarCompra(4000));
		System.out.println(tarjeta.toString());
		tarjeta.actualizarLimite(3000);
		System.out.println(tarjeta.toString());
		
		tarjeta.setTitular("Jhon Doe");
		System.out.println("El titular de la tarjeta ahora es: "+tarjeta.getTitular());
	}

}
//2. Crear una clase llamada Tarjeta de Credito.
//� Atributos privados:
//- String numero
//- String titular
//- double limite
//- double disponible
//� M�todos p�blicos: setters y getters para cada atributo, y el m�todo toString().
//� Constructor que asigne n�mero, titular y limite. El disponible ser� igual al l�mite.
//Crear los m�todos:
//- puedoComprar, m�todo privado que seg�n un monto devuelve true si puede
//hacer la compra, o false en caso contrario.
//- realizarCompra, m�todo p�blico que dado un monto devuelve un booleano si lo
//pudo realizar, actualizando los atributos que corresponda.
//- actualizarLimite, m�todo p�blico que recibe el nuevo l�mite y actualiza a la vez el
//disponible. Si el l�mite es menor al anterior debe decrementar el disponible. Si el
//mismo resulta menor a 0, se lo debe poner en 0.
//Crear la clase Test para crear un objeto tarjeta y probar los m�todos con la siguiente informaci�n
//- Numero 4145414122221111
//- Titular Juan Perez
//- Limite 10000
//Hacer una compra de 4000
//Ver la informaci�n con toString
//- Debe quedar disponible en 6000
//Bajar l�mite a 3000
//Ver la informaci�n con toString
//- Debe quedar disponible en 0
