package ort.edu.thp.tp3.Ejercicio3;

public class SuperHeroe {
	private String nombre;
	private int fuerza;
	private int resistencia;
	private int superPoderes;
	private static int VICTORIA=1;
	private static int DERROTA=2;
	private static int EMPATE=3;
	
	public SuperHeroe(String nombre, int fuerza, int resistencia, int superPoderes) {
		this.setNombre(nombre);
		this.setFuerza(fuerza);
		this.setResistencia(resistencia);
		this.setSuperpoderes(superPoderes);		
	}
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int getFuerza() {
		return fuerza;
	}
	public void setFuerza(int fuerza) {
		this.fuerza = fuerza;
	}
	public int getResistencia() {
		return resistencia;
	}
	public void setResistencia(int resistencia) {
		this.resistencia = resistencia;
	}
	public int getSuperpoderes() {
		return superPoderes;
	}
	public void setSuperpoderes(int superpoderes) {
		this.superPoderes = superpoderes;
	}
	@Override
	public String toString() {
		return "Super Heroe [nombre=" + nombre + ", fuerza=" + fuerza + ", resistencia=" + resistencia
				+ ", superpoderes=" + superPoderes + "]";
	}
	
	public int jugar(SuperHeroe heroe) {
		int resultado;
		int contVicHeroe1=0, contVicHeroe2=0;
		
		if (this.getFuerza()>heroe.getFuerza()) {
			contVicHeroe1++;
		}else if(this.getFuerza()<heroe.getFuerza()){
			contVicHeroe2++;
		}
		
		if (this.getResistencia()>heroe.getResistencia()) {
			contVicHeroe1++;
		}else if (this.getResistencia()<heroe.getResistencia()){
			contVicHeroe2++;
		}
		
		if(contVicHeroe1<2 && contVicHeroe2<2) {
			if (this.getSuperpoderes()>heroe.getSuperpoderes()) {
				contVicHeroe1++;
			}else if(this.getSuperpoderes()<heroe.getSuperpoderes()){
				contVicHeroe2++;
			}
		}
		if (contVicHeroe1>contVicHeroe2) {
			resultado = VICTORIA;
		}else if(contVicHeroe1<contVicHeroe2){
			resultado = DERROTA;
		}else {
			resultado = EMPATE;
		}
		return resultado;
	}
	
}
