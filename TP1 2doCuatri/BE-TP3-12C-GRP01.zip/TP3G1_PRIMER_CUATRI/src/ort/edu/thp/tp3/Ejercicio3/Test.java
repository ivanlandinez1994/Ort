package ort.edu.thp.tp3.Ejercicio3;

public class Test {

	public static void main(String[] args) {
		int resultado;
		SuperHeroe superHeroe1 = new SuperHeroe("Batman",90,70,0);
		SuperHeroe superHeroe2 = new SuperHeroe("SuperMan",95,60,70);
		resultado = superHeroe2.jugar(superHeroe1);
		if(resultado==1) {
			System.out.println(resultado+ "(Gano)");
		}else if(resultado==2){
			System.out.println(resultado+ "(Perdio)");
		}else {
			System.out.println(resultado+ "(Empataron)");
		}
		
		superHeroe1.setNombre("Batman el caballero de la noche");
		System.out.println("Ahora el nombre es: "+superHeroe1.getNombre());

	}

}
//3. Crear una clase Superh�roe con atributos:
//- String nombre
//- int fuerza
//- int resistencia
//- int superpoderes
//Tendr�n
//� M�todos p�blicos: setters y getters para cada atributo, y el m�todo toString().
//� Constructor que asigne todos los datos por par�metro
//Crear el m�todo:
//- jugar que dado un superh�roe como par�metro, devuelve 1 si gan�, 2 si perdi� o
//3 si empat�. Para triunfar un superh�roe debe ganar en al menos 2 de los 3
//�tems.
//Realizar una clase Test que contenga el main para probar el correcto funcionamiento de los m�todos
//de la clase previamente realizada con el siguiente ejemplo.
//superHeroe1
//- Nombre Batman
//- Fuerza 90
//- Resistencia 70
//- Superpoderes 0
//superHeroe2
//- Nombre Superman
//- Fuerza 95
//- Resistencia 60
//- Superpoderes 70
//Hacer jugar al superheroe2 contra el superheroe1 y mostrar el resultado por pantalla.
//Debe mostrar 2(Perdi�)
//Hacer jugar al superheroe1 contra el superheroe2 y mostrar el resultado por pantalla. Debe mostrar 1(gan�)
//Crear m�s superh�roes y jugar

