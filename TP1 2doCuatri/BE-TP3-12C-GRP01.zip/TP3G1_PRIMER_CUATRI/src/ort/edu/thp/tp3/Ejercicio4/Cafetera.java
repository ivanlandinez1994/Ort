package ort.edu.thp.tp3.Ejercicio4;

public class Cafetera {
	private int capacidadMaxima;
	private int cantidadActual;
	
/*a*/public Cafetera(){
		this.setCapacidadMaxima(1000);
		this.setCantidadActual(0);		
	}
	
/*b*/public Cafetera(int capacidadMaxima) {
		this.setCapacidadMaxima(capacidadMaxima);
		this.setCantidadActual(capacidadMaxima);		
	}
	
/*c*/public Cafetera(int capacidadMaxima, int cantidadActual) {
		this.setCapacidadMaxima(capacidadMaxima);		
		if(cantidadActual>capacidadMaxima) {
			this.setCantidadActual(capacidadMaxima);			
		}else {
			this.setCantidadActual(cantidadActual);			
		}
	}

/*d*/public int getCapacidadMaxima() {
		return capacidadMaxima;
	}

/*d*/public void setCapacidadMaxima(int capacidadMaxima) {
		this.capacidadMaxima = capacidadMaxima;
	}

/*d*/public int getCantidadActual() {
		return cantidadActual;
	}

/*d*/public void setCantidadActual(int cantidadActual) {
		this.cantidadActual = cantidadActual;
	}
	
/*e*/public void llenarCafetera() {
		this.setCantidadActual(this.getCapacidadMaxima());
	}
	
/*f*/public void servirTaza(int cantidadServir) {
		if (this.getCantidadActual()<cantidadServir){
			this.setCantidadActual(0);
		}else{
			this.setCantidadActual(this.getCantidadActual()-cantidadServir);
		}
	}

/*g*/public void vaciarCafetera() {
		this.setCantidadActual(0);		
	}

/*h*/public void agregarCafe(int cantidadAgregar) {
		this.setCantidadActual(cantidadAgregar);
	}

@Override
public String toString() {
	return "Cafetera [capacidadMaxima=" + capacidadMaxima + ", cantidadActual=" + cantidadActual + "]";
}
	
	
}
