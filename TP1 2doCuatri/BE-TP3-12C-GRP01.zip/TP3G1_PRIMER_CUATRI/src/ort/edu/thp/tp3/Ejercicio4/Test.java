package ort.edu.thp.tp3.Ejercicio4;

public class Test {

	public static void main(String[] args) {
/*a)*/	Cafetera cafetera1 = new Cafetera(); 
/*a)*/	System.out.println(cafetera1.toString());
/*e)*/	cafetera1.llenarCafetera();
/*e)*/	System.out.println(cafetera1.toString());
		System.out.println("");
		
/*b)*/	Cafetera cafetera2 = new Cafetera(2000);
/*b)*/	System.out.println(cafetera2.toString());
/*g)*/	cafetera2.vaciarCafetera();
/*g)*/	System.out.println(cafetera2.toString());
/*h)*/  cafetera2.agregarCafe(200);
/*h)*/	System.out.println(cafetera2.toString());
		System.out.println("");
		
/*c)*/	Cafetera cafetera3 = new Cafetera(1500,600);
/*c)*/	System.out.println(cafetera3.toString());
/*f)*/	cafetera3.servirTaza(800);
/*f)*/	System.out.println(cafetera3.getCantidadActual());
		System.out.println("");
		
/*d)*/	cafetera3.setCapacidadMaxima(2000);
/*d)*/	System.out.println("La capacidad maxima ahora es: "+cafetera3.getCapacidadMaxima());
	}

}
//4. Crear una clase Cafetera con los siguientes atributos:
//- capacidadMaxima (la cantidad m�xima de caf� que puede contener la cafetera)
//- cantidadActual (la cantidad actual de caf� que hay en la cafetera).
//Implementar, al menos, los siguientes m�todos:
//a) Constructor predeterminado: establece la capacidad m�xima en 1000 y la actual en cero
//(cafetera vac�a).
//b) Constructor con la capacidad m�xima de la cafetera: inicializa la cantidad actual de caf� igual
//a la capacidad m�xima.
//c) Constructor con la capacidad m�xima y la cantidad actual. Si la cantidad actual es mayor que
//la capacidad m�xima de la cafetera, la ajustar� al m�ximo.
//d) Setters y Getters.
//e) llenarCafetera():hace que la cantidad actual sea igual a la capacidad m�xima.
//f) servirTaza(int): simula la acci�n de servir una taza con la capacidad indicada por par�metro.
//Si la cantidad actual de caf� �no alcanza� para llenar la taza, se sirve lo que quede.
//g) vaciarCafetera(): setea la cantidad de caf� actual en cero.
//h) agregarCafe(int): a�ade a la cafetera la cantidad de caf� indicada
//Realizar una clase Test que contenga el main para probar el correcto funcionamiento de los m�todos
//de la clase previamente realizada.
