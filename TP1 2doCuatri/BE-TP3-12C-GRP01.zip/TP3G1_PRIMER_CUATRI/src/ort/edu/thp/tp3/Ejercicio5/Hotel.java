package ort.edu.thp.tp3.Ejercicio5;

public class Hotel {
	private String nombre;
	private String localidad;
	private int habitaciones;
	private int habitacionesDisponibles;
	
	public Hotel() {
		this.setNombre("Jhon");
		this.setLocalidad("C.A.B.A");
		this.setHabitaciones(320);
		this.setHabitacionesDisponibles(130);		
	}
	
	public Hotel(String nombre, String localidad, int habitaciones, int habitacionesDisponibles) {		
		this.setNombre(nombre);
		this.setLocalidad(localidad);
		this.setHabitaciones(habitaciones);
		this.setHabitacionesDisponibles(habitacionesDisponibles);		
	}
	
	public boolean ocuparHabitaciones(int cantidadHabitacionesOcupar) {
		boolean reserva = false;
		if(cantidadHabitacionesOcupar<=this.getHabitacionesDisponibles()) {
			this.setHabitacionesDisponibles(this.getHabitacionesDisponibles() - cantidadHabitacionesOcupar);
			reserva = true;
		}
		return reserva;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getLocalidad() {
		return localidad;
	}

	public void setLocalidad(String localidad) {
		this.localidad = localidad;
	}

	public int getHabitaciones() {
		return habitaciones;
	}

	public void setHabitaciones(int habitaciones) {
		this.habitaciones = habitaciones;
	}

	public int getHabitacionesDisponibles() {
		return habitacionesDisponibles;
	}

	public void setHabitacionesDisponibles(int habitacionesDisponibles) {
		this.habitacionesDisponibles = habitacionesDisponibles;
	}

	@Override
	public String toString() {
		return "Hotel [nombre=" + nombre + ", localidad=" + localidad + ", habitaciones=" + habitaciones
				+ ", habitacionesDisponibles=" + habitacionesDisponibles + "]";
	}
		
}
