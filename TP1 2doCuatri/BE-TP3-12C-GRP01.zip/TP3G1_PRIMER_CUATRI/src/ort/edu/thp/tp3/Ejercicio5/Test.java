package ort.edu.thp.tp3.Ejercicio5;

public class Test {
	public static void main(String args[]) {
		Hotel hilton = new Hotel("Hilton","CABA",200,15);
		System.out.println(hilton.toString());
		System.out.println("Se reservaron las habitaciones: "+hilton.ocuparHabitaciones(20));
		System.out.println("Se reservaron las habitaciones: "+hilton.ocuparHabitaciones(15));
		hilton.setNombre("Hilton2");
		System.out.println("Ahora el nombre del hotel es: "+hilton.getNombre());
	}
	
}
//5. Clase una clase Hotel con los siguientes atributos:
//- nombre,
//- localidad,
//- habitaciones.
//- habitaciones disponibles.
//Implementar los siguientes m�todos y constructores:
//a) Constructores: vac�o y parametrizado completo
//b) ocuparHabitaciones, recibe la cantidad de habitaciones a ocupar, devuelve true o false y
//ocupa o no las habitaciones seg�n las cantidades.
//c) getters, setters y toString
//Crear el objeto en una clase Test con los siguientes datos "Hilton", "CABA", 200, 15
//y probar todos los m�todos.
