package ort.edu.thp.tp3.Ejercicio6;

public class Test {

	public static void main(String[] args) {
		Vuelo vuelo1 = new Vuelo("Aeroparque","Miami","01/06/2018",1234,250);
		vuelo1.setAsientosOcupados(15);
		System.out.println(vuelo1.getAsientosOcupados());
		System.out.println(vuelo1.toString());
		System.out.println("La reserva por "+50+" se hizo: "+vuelo1.reservar(50));
		System.out.println(vuelo1.toString());
		System.out.println("Los asientos disponibles son "+(vuelo1.getCapacidad()-vuelo1.getAsientosOcupados()));
		
	}
}
//6. Crear una clase Vuelo con los siguientes atributos:
//- origen
//- destino
//- fecha
//- numero
//- capacidad
//- asientosOcupados
//Implementar los siguientes m�todos y constructores:
//a) Constructores con origen, destino, fecha, n�mero, capacidad
//b) reservar , recibe la cantidad de personas que quieren reservar asientos . Actualiza la
//cantidad de asientos ocupados, devuelve true o false.
//c) getters, setters y toString
//Crear el objeto en la clase Test con la siguiente informacion "Aeroparque","Miami",
//"01/06/2018",1234,250 , utilizando constructor
//Asientos ocupados:15 (con setter)
//Probar el metodo reservar (con los casos para que edvuelva true o false)