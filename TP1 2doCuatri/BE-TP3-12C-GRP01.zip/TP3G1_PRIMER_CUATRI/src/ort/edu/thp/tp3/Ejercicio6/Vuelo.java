package ort.edu.thp.tp3.Ejercicio6;

public class Vuelo {
	private String origen;
	private String destino;
	private String fecha;
	private int numero;
	private int capacidad;
	private int asientosOcupados;
	
	public Vuelo(String origen, String destino, String fecha, int numero, int capacidad) {
		this.setOrigen(origen);
		this.setDestino(destino);
		this.setFecha(fecha);
		this.setNumero(numero);
		this.setCapacidad(capacidad);		
	}
	public boolean reservar(int cantPersonasReservar) {
		boolean reservo=false;
		if(cantPersonasReservar<=(this.getCapacidad()-this.getAsientosOcupados())) {
			this.setAsientosOcupados(this.getAsientosOcupados() + cantPersonasReservar);
			reservo=true;
		}
		return reservo;
	}
	public String getOrigen() {
		return origen;
	}
	public void setOrigen(String origen) {
		this.origen = origen;
	}
	public String getDestino() {
		return destino;
	}
	public void setDestino(String destino) {
		this.destino = destino;
	}
	public String getFecha() {
		return fecha;
	}
	public void setFecha(String fecha) {
		this.fecha = fecha;
	}
	public int getNumero() {
		return numero;
	}
	public void setNumero(int numero) {
		this.numero = numero;
	}
	public int getCapacidad() {
		return capacidad;
	}
	public void setCapacidad(int capacidad) {
		this.capacidad = capacidad;
	}
	public int getAsientosOcupados() {
		return asientosOcupados;
	}
	public void setAsientosOcupados(int asientosOcupados) {
		this.asientosOcupados = asientosOcupados;
	}
	@Override
	public String toString() {
		return "Vuelo [origen=" + origen + ", destino=" + destino + ", fecha=" + fecha + ", numero=" + numero
				+ ", capacidad=" + capacidad + ", asientosOcupados=" + asientosOcupados + "]";
	}
	
}
