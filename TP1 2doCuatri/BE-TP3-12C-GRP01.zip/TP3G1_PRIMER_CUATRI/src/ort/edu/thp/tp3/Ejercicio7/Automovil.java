package ort.edu.thp.tp3.Ejercicio7;

public class Automovil {
	private String marca;
	private String modelo;
	private String patente;
	private double capacidadCombustible;
	private double cantidadCombustible;
	private double kmPorLitro; //(representa cuantos kilometros recorre con un litro de combustible)
	
	public Automovil() {
		this.setMarca("Mazda");
		this.setModelo("2012");
		this.setPatente("AQG 02C");
		this.setCapacidadCombustible(50);
		this.setCantidadCombustible(10);
		this.setKmPorLitro(2); //recorre 2 kilometros con un litro
	}
	
	public Automovil(String marca, String modelo, String patente) {
		this.setMarca(marca);
		this.setModelo(modelo);
		this.setPatente(patente);		
	}
	
	public boolean viajar(double kilometros) {
		boolean seHizoElViaje=false;
		if(kilometros<=(this.getCantidadCombustible()/this.getKmPorLitro())) {
			this.setCantidadCombustible(this.getCantidadCombustible() - (kilometros/this.getKmPorLitro()));
			seHizoElViaje=true;
		}
		return seHizoElViaje;
	}
	
	public boolean cargarCombustible(double cantidadACargar) {
		boolean seCargo=false;
		if(verificarCantidad(cantidadACargar)) {
			this.setCantidadCombustible(this.getCantidadCombustible() + cantidadACargar);
			seCargo=true;
		}
		return seCargo;
	}
	
	private boolean verificarCantidad(double cantidad) {
		boolean sePuede=false;
		if(cantidad<=(this.getCapacidadCombustible()-this.getCantidadCombustible())) {
			sePuede=true;
		}
		return sePuede;
	}

	
	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	public String getPatente() {
		return patente;
	}

	public void setPatente(String patente) {
		this.patente = patente;
	}

	public double getCapacidadCombustible() {
		return capacidadCombustible;
	}

	public void setCapacidadCombustible(double capacidadCombustible) {
		this.capacidadCombustible = capacidadCombustible;
	}

	public double getCantidadCombustible() {
		return cantidadCombustible;
	}

	public void setCantidadCombustible(double cantidadCombustible) {
		this.cantidadCombustible = cantidadCombustible;
	}

	public double getKmPorLitro() {
		return kmPorLitro;
	}

	public void setKmPorLitro(double kmPorLitro) {
		this.kmPorLitro = kmPorLitro;
	}

	@Override
	public String toString() {
		return "Automovil [marca=" + marca + ", modelo=" + modelo + ", patente=" + patente
				+ ", capacidadCombustible=" + capacidadCombustible + ", cantidadCombustible=" + cantidadCombustible
				+ ", kmPorLitro=" + kmPorLitro + "]";
	}
	
	
}
