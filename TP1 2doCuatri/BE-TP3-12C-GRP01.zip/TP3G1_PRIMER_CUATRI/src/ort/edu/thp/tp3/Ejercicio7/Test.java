package ort.edu.thp.tp3.Ejercicio7;

public class Test {
	public static void main(String args[]) {
		Automovil auto1 = new Automovil("Ford","Fiesta","ABCD123");
		auto1.setCapacidadCombustible(40);
		auto1.setCantidadCombustible(20);
		auto1.setKmPorLitro(10);
		System.out.println(auto1.toString());
		System.out.println("Se cargo el combustible: "+auto1.cargarCombustible(20));
		System.out.println("Cantidad de combustible actual: "+auto1.getCantidadCombustible()+" litros.");
		System.out.println("Se puede realizar el viaje?: "+auto1.viajar(4));
	}
}
//7. Crear una clase Automovil con los siguientes atributos:
//- marca
//- modelo
//- patente
//- capacidadCombustible
//- cantidadCombustible
//- kmPorLitro(representa cuantos kilometros recorre con un litro de combustible)
//Implementar los siguientes m�todos y constructores:
//a) Constructores: vac�o y otro con marca, modelo, patente
//b) viajar , recibe la cantidad de kilometros. Actualiza la cantidad de Nafta, devuelve true o false.
//c) cargarCombustible, devuelve true o false, recibe la cantidad que se quiere cargar, llama a
//verificarCantidad para ver si puede cargar dicha cantidad. si puede actualiza la cantidad de
//nafta.
//d) verificarCantidad combustible (metodo privado que va a ser llamado por cargrCombustible)
//devuelve true o false, recibe la cantidad que se quiere verificar.
//e) getters, setters y toString
//Cuando se cree el objeto, la informaci�n debe enviarse a traves del constructor, la capacidad y la
//cantidad de combustible se dar� de alta con el setter,
//Crear el objeto "Ford","Fiesta", "ABCD123"
//Capacidad:40
//Cantidad: 20
//Kilometros por litro: 10
//Probar todos los m�todos
