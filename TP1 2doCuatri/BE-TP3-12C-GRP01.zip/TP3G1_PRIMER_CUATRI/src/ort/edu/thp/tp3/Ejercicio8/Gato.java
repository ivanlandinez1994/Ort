package ort.edu.thp.tp3.Ejercicio8;

public class Gato {
	private int energia;
	private int metroPorEnergia;
	
	public Gato(int energia, int metroPorEnergia){// se obliga a usar un constructor dado que la variable metro por energia no puede ser 0
		this.setEnergia(energia);
		this.setMetroPorEnergia(metroPorEnergia);
	}
	
	public int getEnergia() {
		return energia;
	}
	public void setEnergia(int energia) {
		this.energia = energia;
	}
	public int getMetroPorEnergia() {
		return metroPorEnergia;
	}
	public void setMetroPorEnergia(int metroPorEnergia) {
		if(metroPorEnergia>0){ //se condiciona dado que la variable metro por energia no puede ser < 0
			this.metroPorEnergia = metroPorEnergia;
		}
	}
	@Override
	public String toString() {
		return "Ejercicio8Gato [energia=" + energia + ", metroPorEnergia=" + metroPorEnergia + "]";
	}
	
	public boolean alcanzar(Raton raton1, int distancia) {
		boolean loAlcanzo=false;
		int metroAlcanzadoGato; 
		int metroAlcanzadoRaton;
		int maxMetrosAlcanzaGato = this.getEnergia()/this.getMetroPorEnergia();
		int maxMetrosAlcanzaRaton = raton1.getEnergia()/raton1.getMetroPorEnergia();
		if(maxMetrosAlcanzaGato>=distancia) {
			metroAlcanzadoGato = maxMetrosAlcanzaGato - distancia;
			metroAlcanzadoRaton = maxMetrosAlcanzaRaton - distancia ;
			if(metroAlcanzadoGato>=metroAlcanzadoRaton) {
				loAlcanzo=true;
			}
		}	
		return loAlcanzo;
	}
	
}
