package ort.edu.thp.tp3.Ejercicio8;

public class Raton {
	private int energia;
	private int metroPorEnergia;
	
	public Raton(int energia, int metroPorEnergia){// se obliga a usar un constructor dado que la variable metro por energia no puede ser 0
		this.setEnergia(energia);
		this.setMetroPorEnergia(metroPorEnergia);
	}
	
	public int getEnergia() {
		return energia;
	}
	public void setEnergia(int energia) {
		this.energia = energia;
	}
	public int getMetroPorEnergia() {
		return metroPorEnergia;
	}
	public void setMetroPorEnergia(int metroPorEnergia) {
		if (metroPorEnergia>0){//se condiciona dado que la variable metro por energia no puede ser < 0
			this.metroPorEnergia = metroPorEnergia;
		}
	}
	@Override
	public String toString() {
		return "Ejercicio8Raton [energia=" + energia + ", metroPorEnergia=" + metroPorEnergia + "]";
	}
	
}
