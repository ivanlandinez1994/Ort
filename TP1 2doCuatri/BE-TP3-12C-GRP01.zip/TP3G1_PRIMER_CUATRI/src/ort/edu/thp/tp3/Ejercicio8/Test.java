package ort.edu.thp.tp3.Ejercicio8;

public class Test {

	public static void main(String[] args) {
		Gato gato1 = new Gato(200,2);// se inicializan los valores dado que los metros por energia no pueden ser <0
		Raton raton1 = new Raton(200,4);// se inicializan los valores dado que los metros por energia no pueden ser <0
		gato1.setEnergia(100);
		gato1.setMetroPorEnergia(1);
		raton1.setEnergia(100);
		raton1.setMetroPorEnergia(2);
		System.out.println("El gato alcanzo al raton: "+gato1.alcanzar(raton1, 50));
	}

}
//8. Crear una clase Gato y una clase Raton
//Ambos tienen como atributo energ�a.
//Un gato puede correr mientras le de la energ�a, descontando un punto de energ�a por metro corrido.
//Lo mismo el rat�n pero se le descuentan 2 puntos de energ�a por cada metro corrido. Es decir un gato
//o un rat�n corren x cantidad de metros seg�n la energ�a
//implementar un m�todo en Gato que se llame alcanzar y reciba como par�metro un rat�n y la
//distancia que debe recorrer para alcanzarlo, si lo alcanza devuelve true, caso contrario false.
//Ejemplo, un gato con 100 de energ�a puede correr 100 metros, un rat�n con 100 de energ�a puede
//correr 50 metros. O sea que si el rat�n est� a m�s de 50 metros del gato y ambos tienen 100 de
//energ�a, no lo va a alcanzar.
//Crear un gato y un rat�n en una clase Test y jugar