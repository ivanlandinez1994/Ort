package ar.edu.ort.tp1.tp3.ejercicio3;

public enum TipoLavarropa {
	AUTOMATICO, SEMIAUTOMATICO
}
