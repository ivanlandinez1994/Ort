package ar.edu.ort.tp1.tp3.ejercicio4;

public enum EstadoJornada {
	ABIERTO, FINALIZADO
}
