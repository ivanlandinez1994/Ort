package ar.edu.ort.tp1.tp3.ejercicio4;

public class Jugador {
	private String nombre;
	private String documento;
	private int edad;
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getDocumento() {
		return documento;
	}
	public void setDocumento(String documento) {
		this.documento = documento;
	}
	public int getEdad() {
		return edad;
	}
	public void setEdad(int edad) {
		this.edad = edad;
	}
	
	@Override
	public String toString() {
		return "Nombre: "+nombre+", documento: "+documento+", edad: "+edad;
	}
	
}
