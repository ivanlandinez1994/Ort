package ar.edu.ort.tp1.tp3.ejercicio4;

public enum TipoTorneo {
	FUTBOL_5, FUTBOL_8, FUTBOL_11;
}
